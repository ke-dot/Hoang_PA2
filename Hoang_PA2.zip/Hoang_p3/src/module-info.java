module Hoang_p3 {
}