module Hoang_p1 {
}