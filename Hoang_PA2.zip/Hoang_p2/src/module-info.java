module Hoang_p2 {
}